"""Dockable analysis panels."""
